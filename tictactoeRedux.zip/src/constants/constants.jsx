export const PLAYERX = "Player 1 - Xs ";
export const PLAYER0 = "Player 2 - 0s ";
export const VALUES = [
    ["-", "-", "-"],
    ["-", "-", "-"],
    ["-", "-", "-"]
];