import React from 'react';
//import logo from '../logo.svg';
import '../assets/styles/index.css';
import Header from './Header';
import Board from './Board';
//import { tsConstructorType } from '@babel/types';
import { connect } from "react-redux";
import { playPosition, resetGame } from '../reducers/actions';

class App extends React.Component {
  constructor(props) {
    
    super(props);
    this.appClick = this.appClick.bind(this);
    this.reset = this.reset.bind(this)
    console.log('APPPP')
  }

  appClick(rowIndex, columIndex) {
    console.log('click')
    this.props.dispatch(playPosition(rowIndex, columIndex, this.props.turn, this.props.movements));
  }

  reset() {
    console.log('Reeeeeeeeset');
    this.props.dispatch(resetGame());
  }

  render() {
    let text = "Turn of " + this.props.turn;
    return (
      <div>
        <Header textt={text}>
        </Header>
        <Board appClick={this.appClick} values={this.props.values}>
        </Board>
        <p>Number of movements: {this.props.movements}</p>
        <button onClick={this.reset}>RESET</button>
      </div>
    );
  }
}

//this function map the state to  props
function mapStateToProps(state) {
  console.log('mapstatetoprops')
  return {
    values: state.values,
    turn: state.turn,
    movements: state.movements
  }
};

//we export our App as a param
export default connect(mapStateToProps)(App);
//export default App;
