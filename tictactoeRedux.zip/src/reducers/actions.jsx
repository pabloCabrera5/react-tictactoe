export function playPosition(x, y, turn, movements) {
    console.log('playPosition')
    return {
        type: 'PLAY_POSITION',
        x: x,
        y: y,
        turn: turn,
        movements: movements
    }
}

export function resetGame(){
    console.log('resetGameeeee')
    return {
        type: 'RESET',
    }
}