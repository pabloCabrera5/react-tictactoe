import { combineReducers } from "redux";
import gameRecuder from './gameReducer';
import turnReducer from "./turnReducer";
import move from "./moveReducer";

export const globalState = combineReducers({
    turn: turnReducer,
    values: gameRecuder,
    movements: move
});

