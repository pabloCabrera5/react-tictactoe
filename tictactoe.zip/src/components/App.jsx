import React from 'react';
import logo from '../logo.svg';
import '../assets/styles/index.css';
import Header from './Header';
import Board from './Board';
import { tsConstructorType } from '@babel/types';
const PLAYERX = "Player 1 -Xs ";
const PLAYER0 = "Player 2 -Xs ";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      turn: PLAYERX,
      values: [
        ["-", "-", "-"],
        ["-", "-", "-"],
        ["-", "-", "-"]
      ],
      movements: 0
    }
    this.appClick = this.appClick.bind(this);
    this.reset = this.reset.bind(this)
  }

  appClick(rowIndex, columIndex) {
    let addmove = this.state.movements + 1;
    let newValues = JSON.parse(JSON.stringify(this.state.values));
    newValues[rowIndex][columIndex] = this.state.turn === PLAYERX ? "X" : "0";
    this.setState({
      turn: this.state.turn === PLAYERX ? PLAYER0 : PLAYERX,
      values: newValues,
      movements: addmove
    }, () => {
      this.checkWinner(this.state.values)
    })
  }
  checkWinner(board) {
    let wincolum = this.checkColumn(board);
    let winRow = this.checkRow(board);
    let winDiagonal = this.checkDiagonal(board);
    let isFinish = this.isFinish(board);
    
    if (wincolum || winRow || winDiagonal) {
      alert(`${this.state.turn === PLAYERX ? PLAYER0 : PLAYERX} won.`)
      setTimeout(() => {
        this.reset()
      }, 2000);
      return;
    }
    if (isFinish) {
      alert(`Equals, restarting the game...`)
      setTimeout(() => {
        this.reset()
      }, 2000);
    }
  }
  
  checkColumn(board){
    let win = false;
    for (let i = 0; i < board[i].length; i++) {
      if (this.getCol(board, i)) {
        win = true;
      }
      if (!board[i + 1]) break;
    }
    return win;
  }
  checkRow(board){
    let win = false;
    board.forEach(element => {
      if (this.checkArray(element)) {
        win = true;
      }
    });
    return win;
  }
  checkDiagonal(board){
    return this.getDiagonal(board);
  }
  getCol(board, col) {
    let column = [];
    for (let i = 0; i < board.length; i++) {
      column.push(board[i][col]);
    }
    return this.checkArray(column);
  }
  getDiagonal(board){
    let diagonal1 = [];
    let diagonal2 = [];
    let diagonals = [];
    let win = false;
    for (let i= 0,j = 0; i < board[i].length; i++,j++) {
      diagonal1.push(board[i][j]);
      if (!board[i + 1]) break;
    }
    for (let i = 0,j = board[0].length; j > 0; i++,j--) {
      diagonal2.push(board[i][j-1]);
    }
    diagonals.push(diagonal1, diagonal2);
    diagonals.forEach(element => {
      if(this.checkArray(element)){
        win = true;
      }
    });
    return win;
  }
  checkArray(row) {
    let winner = true;
    for (let i = 0; i < row.length - 1; i++) {
      if (row[i] === '-' || row[i] !== row[i + 1]) {
        winner = false;
      }
    }
    return winner;
  }
  isFinish(board){
    let finish = true;
    board.forEach(element => {
      element.map((value) => {
        if (value === '-') {
          finish = false;
        }
      })
    });
    return finish;
  }

  reset() {
    this.setState({
      turn: PLAYERX,
      values: [
        ["-", "-", "-"],
        ["-", "-", "-"],
        ["-", "-", "-"]
      ],
      movements: 0
    })
  }

  render() {
    let text = "Turn of " + this.state.turn;
    return (
      <div>
        <Header textt={text}>
        </Header>
        <Board appClick={this.appClick} values={this.state.values}>
        </Board>
        <p>Number of movements: {this.state.movements}</p>
        <button onClick={this.reset}>RESET</button>
      </div>
    );
  }

}

export default App;
